
## 1. Что должно быть рядом с заданием
В задании обычно есть папка `import`.
Эту папку нужно скопировать внутрь проекта.
## 2. Создайте папку проекта на рабочем столе
Откройте рабочий стол.
Создайте папку:
```text
demoex-py
```
## 3. Скопируйте папку `import`
Скопируйте папку в КОРЕНЬ проекта
## 4. Создайте папку для кода
Внутри `demoex-py` создайте папку:
```text
shoe_shop
```
## 5. Создайте файлы проекта
Внутри `demoex-py` создайте файлы:
```text
run.py
README.md
```
Внутри папки `shoe_shop` создайте файлы:
```text
__init__.py
config.py
database.py
importer.py
ui.py
```
Итоговая структура:
```text
demoex-py/
  import/
  shoe_shop/
    __init__.py
    config.py
    database.py
    importer.py
    ui.py
  .gitignore
  README.md
  requirements.txt
  run.py
```
## 8. Файл `README.md`
python run.py
## 9. Файл `run.py`
Вставьте код:
```python
from shoe_shop.database import initialize_database
from shoe_shop.ui import ShoeShopApp


def main() -> None:
    initialize_database()
    app = ShoeShopApp()
    app.mainloop()


if __name__ == "__main__":
    main()


```

## 10. Файл `shoe_shop/__init__.py`
Вставьте:
```python
"""Shoe shop demo exam project."""
```
## 11. Файл `shoe_shop/config.py`
Вставьте код:

```python
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "shoe_shop.db"
IMPORT_DIR = BASE_DIR / "import"
ASSETS_DIR = BASE_DIR / "assets"
IMAGE_DIR = ASSETS_DIR / "images"

APP_TITLE = "ООО Обувь"

```
## 12. Файл `shoe_shop/database.py`
Вставьте код:

```python
import sqlite3

from shoe_shop.config import DATA_DIR, DB_PATH


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    login TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('ADMIN', 'MANAGER', 'CLIENT')),
    full_name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL,
    price REAL NOT NULL CHECK (price > 0),
    discount INTEGER NOT NULL DEFAULT 0 CHECK (discount BETWEEN 0 AND 100),
    quantity INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    supplier TEXT NOT NULL DEFAULT '',
    unit TEXT NOT NULL DEFAULT 'шт.',
    manufacturer TEXT NOT NULL DEFAULT '',
    image_url TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS pickup_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    order_date TEXT NOT NULL,
    delivery_date TEXT,
    pickup_point_id INTEGER,
    receive_code TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL,
    total_amount REAL NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (pickup_point_id) REFERENCES pickup_points(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    price REAL NOT NULL CHECK (price > 0),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);
"""


DEMO_USERS = (
    ("admin", "admin", "ADMIN", "Администратор"),
    ("manager", "manager", "MANAGER", "Менеджер"),
    ("client", "client", "CLIENT", "Клиент"),
)


def get_connection() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    with get_connection() as connection:
        connection.executescript(SCHEMA)
        _migrate(connection)
        connection.executemany(
            """
            INSERT INTO users (login, password, role, full_name)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(login) DO NOTHING
            """,
            DEMO_USERS,
        )

    try:
        from shoe_shop.importer import import_exam_resources

        import_exam_resources()
    except FileNotFoundError:
        pass


def _migrate(connection: sqlite3.Connection) -> None:
    for table, column, definition in (
        ("products", "supplier", "TEXT NOT NULL DEFAULT ''"),
        ("products", "unit", "TEXT NOT NULL DEFAULT 'шт.'"),
        ("orders", "delivery_date", "TEXT"),
        ("orders", "pickup_point_id", "INTEGER"),
        ("orders", "receive_code", "TEXT NOT NULL DEFAULT ''"),
    ):
        names = [row["name"] for row in connection.execute(f"PRAGMA table_info({table})")]
        if column not in names:
            connection.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

```

## 13. Файл `shoe_shop/importer.py`
Вставьте код:

```python
import shutil
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET

from shoe_shop.config import IMAGE_DIR, IMPORT_DIR
from shoe_shop.database import get_connection


NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
ROLES = {"Администратор": "ADMIN", "Менеджер": "MANAGER", "Авторизированный клиент": "CLIENT", "Клиент": "CLIENT"}


def import_exam_resources() -> None:
    if not IMPORT_DIR.exists():
        raise FileNotFoundError(IMPORT_DIR)

    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    for path in IMPORT_DIR.iterdir():
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".ico"}:
            shutil.copy2(path, IMAGE_DIR / path.name)

    with get_connection() as db:
        import_users(db)
        import_products(db)
        import_points(db)
        import_orders(db)


def import_users(db) -> None:
    for row in table("user_import.xlsx")[1:]:
        role_name, full_name, login, password = pad(row, 4)
        if login and full_name:
            upsert(db, "users", ("login", "password", "role", "full_name"), (login, password, ROLES.get(role_name, "CLIENT"), full_name), "login")


def import_products(db) -> None:
    for row in table("Tovar.xlsx")[1:]:
        article, name, unit, price, supplier, manufacturer, category, discount, quantity, description, photo = pad(row, 11)
        if not article or not name:
            continue
        upsert(
            db,
            "products",
            ("article", "name", "description", "category", "price", "discount", "quantity", "supplier", "unit", "manufacturer", "image_url"),
            (article, name, description, category, to_float(price), to_int(discount), to_int(quantity), supplier, unit or "шт.", manufacturer, image(photo)),
            "article",
        )


def import_points(db) -> None:
    for row in table("Пункты выдачи_import.xlsx"):
        if row and row[0]:
            db.execute("INSERT OR IGNORE INTO pickup_points (address) VALUES (?)", (row[0],))


def import_orders(db) -> None:
    for row in table("Заказ_import.xlsx")[1:]:
        order_id, items_text, order_date, delivery_date, point_id, full_name, code, status = pad(row, 8)
        if not order_id or not items_text:
            continue

        items = parse_items(items_text)
        user_id = find_or_create_user(db, full_name)
        total = order_total(db, items)
        upsert(
            db,
            "orders",
            ("id", "user_id", "order_date", "delivery_date", "pickup_point_id", "receive_code", "status", "total_amount"),
            (to_int(order_id), user_id, excel_date(order_date), excel_date(delivery_date), to_int(point_id) or None, code, status, total),
            "id",
        )
        db.execute("DELETE FROM order_items WHERE order_id = ?", (to_int(order_id),))
        for article, quantity in items:
            product = db.execute("SELECT id, price, discount FROM products WHERE article = ?", (article,)).fetchone()
            if product:
                price = product["price"] * (100 - product["discount"]) / 100
                db.execute("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)", (to_int(order_id), product["id"], quantity, price))


def upsert(db, table_name: str, columns: tuple[str, ...], values: tuple, conflict: str) -> None:
    names = ", ".join(columns)
    marks = ", ".join("?" for _ in columns)
    updates = ", ".join(f"{name}=excluded.{name}" for name in columns if name != conflict)
    db.execute(f"INSERT INTO {table_name} ({names}) VALUES ({marks}) ON CONFLICT({conflict}) DO UPDATE SET {updates}", values)


def table(file_name: str) -> list[list[str]]:
    with zipfile.ZipFile(IMPORT_DIR / file_name) as archive:
        shared = shared_strings(archive)
        sheet = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))

    result = []
    for row in sheet.findall(".//x:row", NS):
        values = []
        for cell in row.findall("x:c", NS):
            value = cell.find("x:v", NS)
            text = "" if value is None else value.text or ""
            values.append(shared[int(text)] if cell.get("t") == "s" and text else text.strip())
        result.append(values)
    return result


def shared_strings(archive: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    return ["".join(text.text or "" for text in item.findall(".//x:t", NS)) for item in root.findall("x:si", NS)]


def pad(row: list[str], size: int) -> list[str]:
    return [*row, *([""] * size)][:size]


def to_int(value: str) -> int:
    try:
        return int(float(value))
    except ValueError:
        return 0


def to_float(value: str) -> float:
    try:
        return float(value.replace(",", "."))
    except ValueError:
        return 0.0


def image(file_name: str) -> str:
    return f"assets/images/{file_name}" if file_name else "assets/images/picture.png"


def excel_date(value: str) -> str:
    try:
        return (datetime(1899, 12, 30) + timedelta(days=int(float(value)))).strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        for fmt in ("%d.%m.%Y", "%Y-%m-%d"):
            try:
                return datetime.strptime(value, fmt).strftime("%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def parse_items(value: str) -> list[tuple[str, int]]:
    parts = [part.strip() for part in value.split(",") if part.strip()]
    return [(parts[i], to_int(parts[i + 1]) if i + 1 < len(parts) else 1) for i in range(0, len(parts), 2)]


def order_total(db, items: list[tuple[str, int]]) -> float:
    total = 0.0
    for article, quantity in items:
        product = db.execute("SELECT price, discount FROM products WHERE article = ?", (article,)).fetchone()
        if product:
            total += product["price"] * (100 - product["discount"]) / 100 * quantity
    return round(total, 2)


def find_or_create_user(db, full_name: str) -> int:
    user = db.execute("SELECT id FROM users WHERE full_name = ?", (full_name,)).fetchone()
    if user:
        return user["id"]
    cursor = db.execute("INSERT INTO users (login, password, role, full_name) VALUES (?, '123', 'CLIENT', ?)", (full_name.lower().replace(" ", "_"), full_name or "Клиент"))
    return cursor.lastrowid

```

## 14. Файл `shoe_shop/ui.py`
Вставьте код:

```python
import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

from shoe_shop.config import APP_TITLE, IMAGE_DIR
from shoe_shop.database import get_connection


SORTS = {
    "По названию": "name ASC",
    "Цена по возрастанию": "price ASC",
    "Цена по убыванию": "price DESC",
    "Скидка по убыванию": "discount DESC",
    "Остаток по возрастанию": "quantity ASC",
}

ROLES = {
    "ADMIN": "Администратор",
    "MANAGER": "Менеджер",
    "CLIENT": "Клиент",
    "GUEST": "Гость",
}


def rows(sql: str, params: tuple = ()) -> list[dict]:
    with get_connection() as connection:
        return [dict(row) for row in connection.execute(sql, params).fetchall()]


def one(sql: str, params: tuple = ()) -> dict | None:
    with get_connection() as connection:
        row = connection.execute(sql, params).fetchone()
        return dict(row) if row else None


class ShoeShopApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.user: dict | None = None
        self.role = ""
        self.title(APP_TITLE)
        self.geometry("1120x680")
        self.minsize(960, 600)
        self._set_icon()
        self._style()
        self.container = ttk.Frame(self, padding=18)
        self.container.pack(fill="both", expand=True)
        self.show_login()

    def _set_icon(self) -> None:
        icon = IMAGE_DIR / "Icon.png"
        if icon.exists():
            self.icon_image = tk.PhotoImage(file=icon)
            self.iconphoto(True, self.icon_image)

    def _style(self) -> None:
        self.configure(bg="#f4f6f8")
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure(".", font=("Segoe UI", 10), background="#f4f6f8")
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"), background="#f4f6f8")
        style.configure("Panel.TLabel", background="#ffffff")
        style.configure("Panel.TFrame", background="#ffffff", relief="solid", borderwidth=1)
        style.configure("Accent.TButton", foreground="#ffffff", background="#2f6fbb")
        style.configure("Treeview", rowheight=30)
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

    def clear(self) -> None:
        for child in self.container.winfo_children():
            child.destroy()

    def show_login(self) -> None:
        self.clear()
        LoginFrame(self.container, self).pack(fill="both", expand=True)

    def show_products(self) -> None:
        self.clear()
        ProductsFrame(self.container, self).pack(fill="both", expand=True)

    def login(self, user: dict | None, role: str) -> None:
        self.user = user
        self.role = role
        self.show_products()

    def can_filter(self) -> bool:
        return self.role in {"ADMIN", "MANAGER"}

    def can_edit(self) -> bool:
        return self.role == "ADMIN"

    def can_orders(self) -> bool:
        return self.role in {"ADMIN", "MANAGER"}

    def username(self) -> str:
        return "Гость" if self.role == "GUEST" else self.user["full_name"]


class LoginFrame(ttk.Frame):
    def __init__(self, parent, app: ShoeShopApp) -> None:
        super().__init__(parent)
        self.app = app
        self.login_var = tk.StringVar()
        self.password_var = tk.StringVar()
        self.error_var = tk.StringVar()
        self._build()

    def _build(self) -> None:
        panel = ttk.Frame(self, style="Panel.TFrame", padding=28)
        panel.place(relx=0.5, rely=0.5, anchor="center", width=430)

        ttk.Label(panel, text="ООО Обувь", style="Panel.TLabel", font=("Segoe UI", 22, "bold")).pack(anchor="w")
        ttk.Label(panel, text="Информационная система магазина", style="Panel.TLabel").pack(anchor="w", pady=(2, 22))
        ttk.Label(panel, text="Логин", style="Panel.TLabel").pack(anchor="w")
        ttk.Entry(panel, textvariable=self.login_var).pack(fill="x", pady=(4, 12))
        ttk.Label(panel, text="Пароль", style="Panel.TLabel").pack(anchor="w")
        password = ttk.Entry(panel, textvariable=self.password_var, show="*")
        password.pack(fill="x", pady=(4, 12))
        password.bind("<Return>", lambda _event: self.login())

        ttk.Label(panel, textvariable=self.error_var, style="Panel.TLabel", foreground="#b42318").pack(anchor="w", pady=(0, 12))
        ttk.Button(panel, text="Войти", style="Accent.TButton", command=self.login).pack(fill="x", pady=(0, 8))
        ttk.Button(panel, text="Войти как гость", command=lambda: self.app.login(None, "GUEST")).pack(fill="x")
        ttk.Label(panel, text="admin/admin, manager/manager, client/client", style="Panel.TLabel").pack(anchor="w", pady=(18, 0))

    def login(self) -> None:
        user = one("SELECT * FROM users WHERE login = ?", (self.login_var.get().strip(),))
        if not user or user["password"] != self.password_var.get():
            self.error_var.set("Неверный логин или пароль")
            return
        self.app.login(user, user["role"])


class ProductsFrame(ttk.Frame):
    def __init__(self, parent, app: ShoeShopApp) -> None:
        super().__init__(parent)
        self.app = app
        self.by_row: dict[str, dict] = {}
        self.selected: dict | None = None
        self.search_var = tk.StringVar()
        self.category_var = tk.StringVar(value="Все")
        self.sort_var = tk.StringVar(value="По названию")
        self.count_var = tk.StringVar()
        self._build()
        self.load()

    def _build(self) -> None:
        top = ttk.Frame(self)
        top.pack(fill="x", pady=(0, 14))
        ttk.Label(top, text="Каталог товаров", style="Title.TLabel").pack(side="left")
        ttk.Label(top, text=f"{self.app.username()} | {ROLES[self.app.role]}").pack(side="left", padx=(18, 0))
        ttk.Button(top, text="Выйти", command=self.logout).pack(side="right")

        if self.app.can_filter():
            filters = ttk.Frame(self)
            filters.pack(fill="x", pady=(0, 10))
            ttk.Label(filters, text="Поиск").pack(side="left")
            ttk.Entry(filters, textvariable=self.search_var, width=28).pack(side="left", padx=(6, 14))
            ttk.Label(filters, text="Категория").pack(side="left")
            self.category_box = ttk.Combobox(filters, textvariable=self.category_var, width=18, state="readonly")
            self.category_box.pack(side="left", padx=(6, 14))
            ttk.Label(filters, text="Сортировка").pack(side="left")
            ttk.Combobox(filters, textvariable=self.sort_var, values=list(SORTS), width=22, state="readonly").pack(side="left", padx=(6, 14))
            ttk.Button(filters, text="Применить", command=self.load).pack(side="left")
            ttk.Button(filters, text="Сброс", command=self.reset).pack(side="left", padx=(8, 0))

        columns = ("article", "name", "category", "price", "discount", "final", "quantity", "supplier", "manufacturer", "image")
        self.table = ttk.Treeview(self, columns=columns, show="headings", selectmode="browse")
        titles = ("Артикул", "Название", "Категория", "Цена", "Скидка", "Со скидкой", "Остаток", "Поставщик", "Производитель", "Фото")
        widths = (90, 150, 120, 80, 70, 90, 70, 120, 120, 95)
        for column, title, width in zip(columns, titles, widths):
            self.table.heading(column, text=title)
            self.table.column(column, width=width, anchor="w")
        self.table.pack(fill="both", expand=True)
        self.table.bind("<<TreeviewSelect>>", self.select)
        self.table.bind("<Double-1>", lambda _event: self.edit())

        bottom = ttk.Frame(self)
        bottom.pack(fill="x", pady=(12, 0))
        ttk.Label(bottom, textvariable=self.count_var).pack(side="left")
        if self.app.can_orders():
            ttk.Button(bottom, text="Заказы", command=lambda: OrdersWindow(self.app)).pack(side="right")
        if self.app.can_edit():
            ttk.Button(bottom, text="Удалить", command=self.delete).pack(side="right", padx=(8, 0))
            ttk.Button(bottom, text="Редактировать", command=self.edit).pack(side="right", padx=(8, 0))
            ttk.Button(bottom, text="Добавить товар", style="Accent.TButton", command=self.add).pack(side="right", padx=(8, 0))

    def load(self) -> None:
        sql = "SELECT *, ROUND(price * (100 - discount) / 100, 2) AS final FROM products WHERE 1=1"
        params: list[str] = []
        if self.app.can_filter():
            if self.search_var.get().strip():
                sql += " AND (LOWER(name) LIKE ? OR LOWER(article) LIKE ? OR LOWER(manufacturer) LIKE ?)"
                value = f"%{self.search_var.get().strip().lower()}%"
                params += [value, value, value]
            if self.category_var.get() != "Все":
                sql += " AND category = ?"
                params.append(self.category_var.get())
        sql += f" ORDER BY {SORTS.get(self.sort_var.get(), 'name ASC')}"
        products = rows(sql, tuple(params))
        total = one("SELECT COUNT(*) AS total FROM products")["total"]

        self.table.delete(*self.table.get_children())
        self.by_row.clear()
        for product in products:
            row_id = self.table.insert("", "end", values=(
                product["article"], product["name"], product["category"], f'{product["price"]:.2f}',
                f'{product["discount"]}%', f'{product["final"]:.2f}', product["quantity"],
                product["supplier"], product["manufacturer"], product["image_url"].replace("assets/images/", ""),
            ))
            self.by_row[row_id] = product
        self.selected = None
        self.count_var.set(f"Показано: {len(products)} из {total}")

        if self.app.can_filter() and hasattr(self, "category_box"):
            categories = ["Все"] + [item["category"] for item in rows("SELECT DISTINCT category FROM products ORDER BY category")]
            self.category_box.configure(values=categories)

    def select(self, _event) -> None:
        selected = self.table.selection()
        self.selected = self.by_row.get(selected[0]) if selected else None

    def reset(self) -> None:
        self.search_var.set("")
        self.category_var.set("Все")
        self.sort_var.set("По названию")
        self.load()

    def add(self) -> None:
        form = ProductForm(self.app)
        self.wait_window(form)
        if form.saved:
            self.load()

    def edit(self) -> None:
        if not self.app.can_edit():
            return
        if not self.selected:
            messagebox.showerror("Ошибка", "Выберите товар")
            return
        form = ProductForm(self.app, self.selected)
        self.wait_window(form)
        if form.saved:
            self.load()

    def delete(self) -> None:
        if not self.selected:
            messagebox.showerror("Ошибка", "Выберите товар")
            return
        if messagebox.askyesno("Подтверждение", f'Удалить товар {self.selected["article"]}?'):
            with get_connection() as connection:
                connection.execute("DELETE FROM products WHERE id = ?", (self.selected["id"],))
            self.load()

    def logout(self) -> None:
        self.app.user = None
        self.app.role = ""
        self.app.show_login()


class ProductForm(tk.Toplevel):
    fields = (
        ("article", "Артикул*"), ("name", "Название*"), ("category", "Категория*"),
        ("price", "Цена*"), ("discount", "Скидка (%)*"), ("quantity", "Количество*"),
        ("supplier", "Поставщик"), ("unit", "Единица"), ("manufacturer", "Производитель"),
        ("image_url", "Изображение"),
    )

    def __init__(self, parent: ShoeShopApp, product: dict | None = None) -> None:
        super().__init__(parent)
        self.product = product
        self.saved = False
        self.vars: dict[str, tk.StringVar] = {}
        self.title("Редактирование товара" if product else "Добавление товара")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.build()

    def build(self) -> None:
        frame = ttk.Frame(self, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=self.title(), font=("Segoe UI", 16, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 14))

        for index, (name, label) in enumerate(self.fields, start=1):
            value = self.product[name] if self.product and name in self.product else ("шт." if name == "unit" else "0" if name == "discount" else "")
            self.vars[name] = tk.StringVar(value=str(value))
            ttk.Label(frame, text=label).grid(row=index, column=0, sticky="w", pady=4)
            ttk.Entry(frame, textvariable=self.vars[name], width=42).grid(row=index, column=1, sticky="ew", pady=4)

        ttk.Label(frame, text="Описание").grid(row=11, column=0, sticky="nw", pady=4)
        self.description = tk.Text(frame, width=40, height=4)
        self.description.insert("1.0", self.product["description"] if self.product else "")
        self.description.grid(row=11, column=1, sticky="ew", pady=4)
        self.error = ttk.Label(frame, foreground="#b42318")
        self.error.grid(row=12, column=0, columnspan=2, sticky="w", pady=(8, 10))

        buttons = ttk.Frame(frame)
        buttons.grid(row=13, column=0, columnspan=2, sticky="e")
        ttk.Button(buttons, text="Сохранить", style="Accent.TButton", command=self.save).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Отмена", command=self.destroy).pack(side="left")

    def save(self) -> None:
        try:
            data = {name: var.get().strip() for name, var in self.vars.items()}
            data["price"] = float(data["price"])
            data["discount"] = int(data["discount"] or 0)
            data["quantity"] = int(data["quantity"])
            if not data["article"] or not data["name"] or not data["category"]:
                raise ValueError("Заполните артикул, название и категорию")
            if data["price"] <= 0:
                raise ValueError("Цена должна быть больше 0")
            if data["discount"] < 0 or data["discount"] > 100:
                raise ValueError("Скидка должна быть от 0 до 100")
            if data["quantity"] < 0:
                raise ValueError("Количество не может быть отрицательным")

            current_id = self.product["id"] if self.product else 0
            if one("SELECT id FROM products WHERE LOWER(article)=LOWER(?) AND id<>?", (data["article"], current_id)):
                raise ValueError("Товар с таким артикулом уже существует")

            data["description"] = self.description.get("1.0", "end").strip()
            data["unit"] = data["unit"] or "шт."
            columns = ("article", "name", "description", "category", "price", "discount", "quantity", "supplier", "unit", "manufacturer", "image_url")
            with get_connection() as connection:
                if self.product:
                    values = [data[column] for column in columns] + [self.product["id"]]
                    connection.execute(f"UPDATE products SET {', '.join(column + '=?' for column in columns)} WHERE id=?", values)
                else:
                    values = [data[column] for column in columns]
                    marks = ", ".join("?" for _ in columns)
                    connection.execute(f"INSERT INTO products ({', '.join(columns)}) VALUES ({marks})", values)
            self.saved = True
            self.destroy()
        except (ValueError, sqlite3.IntegrityError) as error:
            self.error.configure(text=str(error))


class OrdersWindow(tk.Toplevel):
    def __init__(self, parent: ShoeShopApp) -> None:
        super().__init__(parent)
        self.title("Просмотр заказов")
        self.geometry("980x420")
        ttk.Label(self, text="Заказы", style="Title.TLabel").pack(anchor="w", padx=18, pady=(16, 10))

        columns = ("id", "user", "date", "delivery", "point", "code", "status", "total")
        titles = ("Номер", "Клиент", "Дата", "Доставка", "Пункт выдачи", "Код", "Статус", "Сумма")
        table = ttk.Treeview(self, columns=columns, show="headings")
        for column, title in zip(columns, titles):
            table.heading(column, text=title)
            table.column(column, width=120 if column != "point" else 260)
        table.pack(fill="both", expand=True, padx=18, pady=(0, 18))

        data = rows(
            """
            SELECT orders.*, users.full_name, pickup_points.address
            FROM orders
            JOIN users ON users.id = orders.user_id
            LEFT JOIN pickup_points ON pickup_points.id = orders.pickup_point_id
            ORDER BY orders.order_date DESC
            """
        )
        for order in data:
            table.insert("", "end", values=(
                order["id"], order["full_name"], order["order_date"][:10],
                (order["delivery_date"] or "")[:10], order["address"] or "",
                order["receive_code"], order["status"], f'{order["total_amount"]:.2f}',
            ))
```

## 15. Проверьте Python

В PowerShell внутри папки проекта выполните:

```powershell
python --version
```

Если Python установлен, появится версия, например:

```text
Python 3.13.2
```

## 16. Проверьте, что tkinter работает

Проект использует `tkinter`, поэтому Python должен уметь открывать окна.

Выполните:

```powershell
python -m tkinter
```

Если все хорошо, откроется маленькое тестовое окно Tcl/Tk.

Если окно не открылось и появилась ошибка:

```text
Can't find a usable init.tcl
This probably means that Tcl wasn't installed properly.
```

значит Python установлен без компонента Tcl/Tk.

Решение:

1. Скачайте установщик Python с официального сайта.
2. Запустите установщик.
3. Нажмите `Modify` или переустановите Python.
4. Обязательно включите компонент:

```text
tcl/tk and IDLE
```

5. Завершите установку.
6. Снова выполните:

```powershell
python -m tkinter
```

Только после успешной проверки `tkinter` запускайте проект.

## 17. Проверьте код

Выполните:

```powershell
python -m compileall .
```

Если ошибок нет, проект собран правильно.

Важно: `compileall` проверяет только синтаксис кода. Он не проверяет, может ли Python открыть окно.

## 18. Первый запуск

Выполните:

```powershell
python run.py
```

При первом запуске автоматически появятся папки:

```text
data/
assets/
assets/images/
```

В папке `data` будет база:

```text
shoe_shop.db
```

В папке `assets/images` будут скопированы картинки из `import`.

Если при запуске ничего не происходит, запускайте именно из PowerShell:

```powershell
cd "$env:USERPROFILE\OneDrive\Рабочий стол\demoex-py"
python run.py
```

Так вы увидите текст ошибки.

## 19. Данные для входа

Можно войти тестовыми пользователями:

```text
admin / admin
manager / manager
client / client
```

Также импортируются пользователи из файла:

```text
import/user_import.xlsx
```

## 20. Проверка ролей

Гость:

```text
видит товары
не видит фильтры
не может добавлять/редактировать/удалять
```

Клиент:

```text
видит товары
не видит фильтры
не может добавлять/редактировать/удалять
```

Менеджер:

```text
видит товары
видит поиск, фильтр, сортировку
видит заказы
не может редактировать товары
```

Администратор:

```text
видит товары
видит поиск, фильтр, сортировку
видит заказы
может добавлять товары
может редактировать товары
может удалять товары
```

## 21. Проверка импорта данных

В PowerShell выполните:

```powershell
python -c "from shoe_shop.database import initialize_database, get_connection; initialize_database(); c=get_connection(); print('users', c.execute('select count(*) from users').fetchone()[0]); print('products', c.execute('select count(*) from products').fetchone()[0]); print('orders', c.execute('select count(*) from orders').fetchone()[0]); print('order_items', c.execute('select count(*) from order_items').fetchone()[0]); print('pickup_points', c.execute('select count(*) from pickup_points').fetchone()[0]); c.close()"
```

Ожидаемый результат для текущей папки `import`:

```text
users 13
products 30
orders 10
order_items 20
pickup_points 36
```

Папки `data`, `assets` создаются автоматически после запуска.
