# Магазин обуви на Python

Упрощенный учебный проект для демоэкзамена.

## Запуск

```powershell
python run.py
```

При запуске приложение создает базу `data/shoe_shop.db`.
Если рядом есть папка `import`, данные автоматически загружаются из Excel:

```text
Tovar.xlsx                 товары
user_import.xlsx           пользователи
Заказ_import.xlsx          заказы
Пункты выдачи_import.xlsx  пункты выдачи
*.jpg, *.png, *.ico        изображения и иконка
```

## Пользователи

```text
admin / admin
manager / manager
client / client
```

## Структура

```text
run.py                 запуск
shoe_shop/config.py    пути проекта
shoe_shop/database.py  SQLite и создание таблиц
shoe_shop/importer.py  импорт папки import
shoe_shop/ui.py        весь интерфейс
```
