from shoe_shop.database import initialize_database
from shoe_shop.ui import ShoeShopApp


def main() -> None:
    initialize_database()
    app = ShoeShopApp()
    app.mainloop()


if __name__ == "__main__":
    main()
