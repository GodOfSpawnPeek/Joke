"""Shoe shop demo exam project."""
