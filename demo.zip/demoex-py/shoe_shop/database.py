import sqlite3

from shoe_shop.config import DATA_DIR, DB_PATH


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    login TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('ADMIN', 'MANAGER', 'CLIENT')),
    full_name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    article TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL,
    price REAL NOT NULL CHECK (price > 0),
    discount INTEGER NOT NULL DEFAULT 0 CHECK (discount BETWEEN 0 AND 100),
    quantity INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    supplier TEXT NOT NULL DEFAULT '',
    unit TEXT NOT NULL DEFAULT 'шт.',
    manufacturer TEXT NOT NULL DEFAULT '',
    image_url TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS pickup_points (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    order_date TEXT NOT NULL,
    delivery_date TEXT,
    pickup_point_id INTEGER,
    receive_code TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL,
    total_amount REAL NOT NULL DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (pickup_point_id) REFERENCES pickup_points(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    price REAL NOT NULL CHECK (price > 0),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
);
"""


DEMO_USERS = (
    ("admin", "admin", "ADMIN", "Администратор"),
    ("manager", "manager", "MANAGER", "Менеджер"),
    ("client", "client", "CLIENT", "Клиент"),
)


def get_connection() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database() -> None:
    DATA_DIR.mkdir(exist_ok=True)
    with get_connection() as connection:
        connection.executescript(SCHEMA)
        _migrate(connection)
        connection.executemany(
            """
            INSERT INTO users (login, password, role, full_name)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(login) DO NOTHING
            """,
            DEMO_USERS,
        )

    try:
        from shoe_shop.importer import import_exam_resources

        import_exam_resources()
    except FileNotFoundError:
        pass


def _migrate(connection: sqlite3.Connection) -> None:
    for table, column, definition in (
        ("products", "supplier", "TEXT NOT NULL DEFAULT ''"),
        ("products", "unit", "TEXT NOT NULL DEFAULT 'шт.'"),
        ("orders", "delivery_date", "TEXT"),
        ("orders", "pickup_point_id", "INTEGER"),
        ("orders", "receive_code", "TEXT NOT NULL DEFAULT ''"),
    ):
        names = [row["name"] for row in connection.execute(f"PRAGMA table_info({table})")]
        if column not in names:
            connection.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
