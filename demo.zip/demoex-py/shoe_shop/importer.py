import shutil
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET

from shoe_shop.config import IMAGE_DIR, IMPORT_DIR
from shoe_shop.database import get_connection


NS = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
ROLES = {"Администратор": "ADMIN", "Менеджер": "MANAGER", "Авторизированный клиент": "CLIENT", "Клиент": "CLIENT"}


def import_exam_resources() -> None:
    if not IMPORT_DIR.exists():
        raise FileNotFoundError(IMPORT_DIR)

    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    for path in IMPORT_DIR.iterdir():
        if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".ico"}:
            shutil.copy2(path, IMAGE_DIR / path.name)

    with get_connection() as db:
        import_users(db)
        import_products(db)
        import_points(db)
        import_orders(db)


def import_users(db) -> None:
    for row in table("user_import.xlsx")[1:]:
        role_name, full_name, login, password = pad(row, 4)
        if login and full_name:
            upsert(db, "users", ("login", "password", "role", "full_name"), (login, password, ROLES.get(role_name, "CLIENT"), full_name), "login")


def import_products(db) -> None:
    for row in table("Tovar.xlsx")[1:]:
        article, name, unit, price, supplier, manufacturer, category, discount, quantity, description, photo = pad(row, 11)
        if not article or not name:
            continue
        upsert(
            db,
            "products",
            ("article", "name", "description", "category", "price", "discount", "quantity", "supplier", "unit", "manufacturer", "image_url"),
            (article, name, description, category, to_float(price), to_int(discount), to_int(quantity), supplier, unit or "шт.", manufacturer, image(photo)),
            "article",
        )


def import_points(db) -> None:
    for row in table("Пункты выдачи_import.xlsx"):
        if row and row[0]:
            db.execute("INSERT OR IGNORE INTO pickup_points (address) VALUES (?)", (row[0],))


def import_orders(db) -> None:
    for row in table("Заказ_import.xlsx")[1:]:
        order_id, items_text, order_date, delivery_date, point_id, full_name, code, status = pad(row, 8)
        if not order_id or not items_text:
            continue

        items = parse_items(items_text)
        user_id = find_or_create_user(db, full_name)
        total = order_total(db, items)
        upsert(
            db,
            "orders",
            ("id", "user_id", "order_date", "delivery_date", "pickup_point_id", "receive_code", "status", "total_amount"),
            (to_int(order_id), user_id, excel_date(order_date), excel_date(delivery_date), to_int(point_id) or None, code, status, total),
            "id",
        )
        db.execute("DELETE FROM order_items WHERE order_id = ?", (to_int(order_id),))
        for article, quantity in items:
            product = db.execute("SELECT id, price, discount FROM products WHERE article = ?", (article,)).fetchone()
            if product:
                price = product["price"] * (100 - product["discount"]) / 100
                db.execute("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)", (to_int(order_id), product["id"], quantity, price))


def upsert(db, table_name: str, columns: tuple[str, ...], values: tuple, conflict: str) -> None:
    names = ", ".join(columns)
    marks = ", ".join("?" for _ in columns)
    updates = ", ".join(f"{name}=excluded.{name}" for name in columns if name != conflict)
    db.execute(f"INSERT INTO {table_name} ({names}) VALUES ({marks}) ON CONFLICT({conflict}) DO UPDATE SET {updates}", values)


def table(file_name: str) -> list[list[str]]:
    with zipfile.ZipFile(IMPORT_DIR / file_name) as archive:
        shared = shared_strings(archive)
        sheet = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))

    result = []
    for row in sheet.findall(".//x:row", NS):
        values = []
        for cell in row.findall("x:c", NS):
            value = cell.find("x:v", NS)
            text = "" if value is None else value.text or ""
            values.append(shared[int(text)] if cell.get("t") == "s" and text else text.strip())
        result.append(values)
    return result


def shared_strings(archive: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    return ["".join(text.text or "" for text in item.findall(".//x:t", NS)) for item in root.findall("x:si", NS)]


def pad(row: list[str], size: int) -> list[str]:
    return [*row, *([""] * size)][:size]


def to_int(value: str) -> int:
    try:
        return int(float(value))
    except ValueError:
        return 0


def to_float(value: str) -> float:
    try:
        return float(value.replace(",", "."))
    except ValueError:
        return 0.0


def image(file_name: str) -> str:
    return f"assets/images/{file_name}" if file_name else "assets/images/picture.png"


def excel_date(value: str) -> str:
    try:
        return (datetime(1899, 12, 30) + timedelta(days=int(float(value)))).strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        for fmt in ("%d.%m.%Y", "%Y-%m-%d"):
            try:
                return datetime.strptime(value, fmt).strftime("%Y-%m-%d %H:%M:%S")
            except ValueError:
                pass
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def parse_items(value: str) -> list[tuple[str, int]]:
    parts = [part.strip() for part in value.split(",") if part.strip()]
    return [(parts[i], to_int(parts[i + 1]) if i + 1 < len(parts) else 1) for i in range(0, len(parts), 2)]


def order_total(db, items: list[tuple[str, int]]) -> float:
    total = 0.0
    for article, quantity in items:
        product = db.execute("SELECT price, discount FROM products WHERE article = ?", (article,)).fetchone()
        if product:
            total += product["price"] * (100 - product["discount"]) / 100 * quantity
    return round(total, 2)


def find_or_create_user(db, full_name: str) -> int:
    user = db.execute("SELECT id FROM users WHERE full_name = ?", (full_name,)).fetchone()
    if user:
        return user["id"]
    cursor = db.execute("INSERT INTO users (login, password, role, full_name) VALUES (?, '123', 'CLIENT', ?)", (full_name.lower().replace(" ", "_"), full_name or "Клиент"))
    return cursor.lastrowid
