import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

from shoe_shop.config import APP_TITLE, IMAGE_DIR
from shoe_shop.database import get_connection


SORTS = {
    "По названию": "name ASC",
    "Цена по возрастанию": "price ASC",
    "Цена по убыванию": "price DESC",
    "Скидка по убыванию": "discount DESC",
    "Остаток по возрастанию": "quantity ASC",
}

ROLES = {
    "ADMIN": "Администратор",
    "MANAGER": "Менеджер",
    "CLIENT": "Клиент",
    "GUEST": "Гость",
}


def rows(sql: str, params: tuple = ()) -> list[dict]:
    with get_connection() as connection:
        return [dict(row) for row in connection.execute(sql, params).fetchall()]


def one(sql: str, params: tuple = ()) -> dict | None:
    with get_connection() as connection:
        row = connection.execute(sql, params).fetchone()
        return dict(row) if row else None


class ShoeShopApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.user: dict | None = None
        self.role = ""
        self.title(APP_TITLE)
        self.geometry("1120x680")
        self.minsize(960, 600)
        self._set_icon()
        self._style()
        self.container = ttk.Frame(self, padding=18)
        self.container.pack(fill="both", expand=True)
        self.show_login()

    def _set_icon(self) -> None:
        icon = IMAGE_DIR / "Icon.png"
        if icon.exists():
            self.icon_image = tk.PhotoImage(file=icon)
            self.iconphoto(True, self.icon_image)

    def _style(self) -> None:
        self.configure(bg="#f4f6f8")
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure(".", font=("Segoe UI", 10), background="#f4f6f8")
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"), background="#f4f6f8")
        style.configure("Panel.TLabel", background="#ffffff")
        style.configure("Panel.TFrame", background="#ffffff", relief="solid", borderwidth=1)
        style.configure("Accent.TButton", foreground="#ffffff", background="#2f6fbb")
        style.configure("Treeview", rowheight=30)
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

    def clear(self) -> None:
        for child in self.container.winfo_children():
            child.destroy()

    def show_login(self) -> None:
        self.clear()
        LoginFrame(self.container, self).pack(fill="both", expand=True)

    def show_products(self) -> None:
        self.clear()
        ProductsFrame(self.container, self).pack(fill="both", expand=True)

    def login(self, user: dict | None, role: str) -> None:
        self.user = user
        self.role = role
        self.show_products()

    def can_filter(self) -> bool:
        return self.role in {"ADMIN", "MANAGER"}

    def can_edit(self) -> bool:
        return self.role == "ADMIN"

    def can_orders(self) -> bool:
        return self.role in {"ADMIN", "MANAGER"}

    def username(self) -> str:
        return "Гость" if self.role == "GUEST" else self.user["full_name"]


class LoginFrame(ttk.Frame):
    def __init__(self, parent, app: ShoeShopApp) -> None:
        super().__init__(parent)
        self.app = app
        self.login_var = tk.StringVar()
        self.password_var = tk.StringVar()
        self.error_var = tk.StringVar()
        self._build()

    def _build(self) -> None:
        panel = ttk.Frame(self, style="Panel.TFrame", padding=28)
        panel.place(relx=0.5, rely=0.5, anchor="center", width=430)

        ttk.Label(panel, text="ООО Обувь", style="Panel.TLabel", font=("Segoe UI", 22, "bold")).pack(anchor="w")
        ttk.Label(panel, text="Информационная система магазина", style="Panel.TLabel").pack(anchor="w", pady=(2, 22))
        ttk.Label(panel, text="Логин", style="Panel.TLabel").pack(anchor="w")
        ttk.Entry(panel, textvariable=self.login_var).pack(fill="x", pady=(4, 12))
        ttk.Label(panel, text="Пароль", style="Panel.TLabel").pack(anchor="w")
        password = ttk.Entry(panel, textvariable=self.password_var, show="*")
        password.pack(fill="x", pady=(4, 12))
        password.bind("<Return>", lambda _event: self.login())

        ttk.Label(panel, textvariable=self.error_var, style="Panel.TLabel", foreground="#b42318").pack(anchor="w", pady=(0, 12))
        ttk.Button(panel, text="Войти", style="Accent.TButton", command=self.login).pack(fill="x", pady=(0, 8))
        ttk.Button(panel, text="Войти как гость", command=lambda: self.app.login(None, "GUEST")).pack(fill="x")
        ttk.Label(panel, text="admin/admin, manager/manager, client/client", style="Panel.TLabel").pack(anchor="w", pady=(18, 0))

    def login(self) -> None:
        user = one("SELECT * FROM users WHERE login = ?", (self.login_var.get().strip(),))
        if not user or user["password"] != self.password_var.get():
            self.error_var.set("Неверный логин или пароль")
            return
        self.app.login(user, user["role"])


class ProductsFrame(ttk.Frame):
    def __init__(self, parent, app: ShoeShopApp) -> None:
        super().__init__(parent)
        self.app = app
        self.by_row: dict[str, dict] = {}
        self.selected: dict | None = None
        self.search_var = tk.StringVar()
        self.category_var = tk.StringVar(value="Все")
        self.sort_var = tk.StringVar(value="По названию")
        self.count_var = tk.StringVar()
        self._build()
        self.load()

    def _build(self) -> None:
        top = ttk.Frame(self)
        top.pack(fill="x", pady=(0, 14))
        ttk.Label(top, text="Каталог товаров", style="Title.TLabel").pack(side="left")
        ttk.Label(top, text=f"{self.app.username()} | {ROLES[self.app.role]}").pack(side="left", padx=(18, 0))
        ttk.Button(top, text="Выйти", command=self.logout).pack(side="right")

        if self.app.can_filter():
            filters = ttk.Frame(self)
            filters.pack(fill="x", pady=(0, 10))
            ttk.Label(filters, text="Поиск").pack(side="left")
            ttk.Entry(filters, textvariable=self.search_var, width=28).pack(side="left", padx=(6, 14))
            ttk.Label(filters, text="Категория").pack(side="left")
            self.category_box = ttk.Combobox(filters, textvariable=self.category_var, width=18, state="readonly")
            self.category_box.pack(side="left", padx=(6, 14))
            ttk.Label(filters, text="Сортировка").pack(side="left")
            ttk.Combobox(filters, textvariable=self.sort_var, values=list(SORTS), width=22, state="readonly").pack(side="left", padx=(6, 14))
            ttk.Button(filters, text="Применить", command=self.load).pack(side="left")
            ttk.Button(filters, text="Сброс", command=self.reset).pack(side="left", padx=(8, 0))

        columns = ("article", "name", "category", "price", "discount", "final", "quantity", "supplier", "manufacturer", "image")
        self.table = ttk.Treeview(self, columns=columns, show="headings", selectmode="browse")
        titles = ("Артикул", "Название", "Категория", "Цена", "Скидка", "Со скидкой", "Остаток", "Поставщик", "Производитель", "Фото")
        widths = (90, 150, 120, 80, 70, 90, 70, 120, 120, 95)
        for column, title, width in zip(columns, titles, widths):
            self.table.heading(column, text=title)
            self.table.column(column, width=width, anchor="w")
        self.table.pack(fill="both", expand=True)
        self.table.bind("<<TreeviewSelect>>", self.select)
        self.table.bind("<Double-1>", lambda _event: self.edit())

        bottom = ttk.Frame(self)
        bottom.pack(fill="x", pady=(12, 0))
        ttk.Label(bottom, textvariable=self.count_var).pack(side="left")
        if self.app.can_orders():
            ttk.Button(bottom, text="Заказы", command=lambda: OrdersWindow(self.app)).pack(side="right")
        if self.app.can_edit():
            ttk.Button(bottom, text="Удалить", command=self.delete).pack(side="right", padx=(8, 0))
            ttk.Button(bottom, text="Редактировать", command=self.edit).pack(side="right", padx=(8, 0))
            ttk.Button(bottom, text="Добавить товар", style="Accent.TButton", command=self.add).pack(side="right", padx=(8, 0))

    def load(self) -> None:
        sql = "SELECT *, ROUND(price * (100 - discount) / 100, 2) AS final FROM products WHERE 1=1"
        params: list[str] = []
        if self.app.can_filter():
            if self.search_var.get().strip():
                sql += " AND (LOWER(name) LIKE ? OR LOWER(article) LIKE ? OR LOWER(manufacturer) LIKE ?)"
                value = f"%{self.search_var.get().strip().lower()}%"
                params += [value, value, value]
            if self.category_var.get() != "Все":
                sql += " AND category = ?"
                params.append(self.category_var.get())
        sql += f" ORDER BY {SORTS.get(self.sort_var.get(), 'name ASC')}"
        products = rows(sql, tuple(params))
        total = one("SELECT COUNT(*) AS total FROM products")["total"]

        self.table.delete(*self.table.get_children())
        self.by_row.clear()
        for product in products:
            row_id = self.table.insert("", "end", values=(
                product["article"], product["name"], product["category"], f'{product["price"]:.2f}',
                f'{product["discount"]}%', f'{product["final"]:.2f}', product["quantity"],
                product["supplier"], product["manufacturer"], product["image_url"].replace("assets/images/", ""),
            ))
            self.by_row[row_id] = product
        self.selected = None
        self.count_var.set(f"Показано: {len(products)} из {total}")

        if self.app.can_filter() and hasattr(self, "category_box"):
            categories = ["Все"] + [item["category"] for item in rows("SELECT DISTINCT category FROM products ORDER BY category")]
            self.category_box.configure(values=categories)

    def select(self, _event) -> None:
        selected = self.table.selection()
        self.selected = self.by_row.get(selected[0]) if selected else None

    def reset(self) -> None:
        self.search_var.set("")
        self.category_var.set("Все")
        self.sort_var.set("По названию")
        self.load()

    def add(self) -> None:
        form = ProductForm(self.app)
        self.wait_window(form)
        if form.saved:
            self.load()

    def edit(self) -> None:
        if not self.app.can_edit():
            return
        if not self.selected:
            messagebox.showerror("Ошибка", "Выберите товар")
            return
        form = ProductForm(self.app, self.selected)
        self.wait_window(form)
        if form.saved:
            self.load()

    def delete(self) -> None:
        if not self.selected:
            messagebox.showerror("Ошибка", "Выберите товар")
            return
        if messagebox.askyesno("Подтверждение", f'Удалить товар {self.selected["article"]}?'):
            with get_connection() as connection:
                connection.execute("DELETE FROM products WHERE id = ?", (self.selected["id"],))
            self.load()

    def logout(self) -> None:
        self.app.user = None
        self.app.role = ""
        self.app.show_login()


class ProductForm(tk.Toplevel):
    fields = (
        ("article", "Артикул*"), ("name", "Название*"), ("category", "Категория*"),
        ("price", "Цена*"), ("discount", "Скидка (%)*"), ("quantity", "Количество*"),
        ("supplier", "Поставщик"), ("unit", "Единица"), ("manufacturer", "Производитель"),
        ("image_url", "Изображение"),
    )

    def __init__(self, parent: ShoeShopApp, product: dict | None = None) -> None:
        super().__init__(parent)
        self.product = product
        self.saved = False
        self.vars: dict[str, tk.StringVar] = {}
        self.title("Редактирование товара" if product else "Добавление товара")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        self.build()

    def build(self) -> None:
        frame = ttk.Frame(self, padding=20)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text=self.title(), font=("Segoe UI", 16, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 14))

        for index, (name, label) in enumerate(self.fields, start=1):
            value = self.product[name] if self.product and name in self.product else ("шт." if name == "unit" else "0" if name == "discount" else "")
            self.vars[name] = tk.StringVar(value=str(value))
            ttk.Label(frame, text=label).grid(row=index, column=0, sticky="w", pady=4)
            ttk.Entry(frame, textvariable=self.vars[name], width=42).grid(row=index, column=1, sticky="ew", pady=4)

        ttk.Label(frame, text="Описание").grid(row=11, column=0, sticky="nw", pady=4)
        self.description = tk.Text(frame, width=40, height=4)
        self.description.insert("1.0", self.product["description"] if self.product else "")
        self.description.grid(row=11, column=1, sticky="ew", pady=4)
        self.error = ttk.Label(frame, foreground="#b42318")
        self.error.grid(row=12, column=0, columnspan=2, sticky="w", pady=(8, 10))

        buttons = ttk.Frame(frame)
        buttons.grid(row=13, column=0, columnspan=2, sticky="e")
        ttk.Button(buttons, text="Сохранить", style="Accent.TButton", command=self.save).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Отмена", command=self.destroy).pack(side="left")

    def save(self) -> None:
        try:
            data = {name: var.get().strip() for name, var in self.vars.items()}
            data["price"] = float(data["price"])
            data["discount"] = int(data["discount"] or 0)
            data["quantity"] = int(data["quantity"])
            if not data["article"] or not data["name"] or not data["category"]:
                raise ValueError("Заполните артикул, название и категорию")
            if data["price"] <= 0:
                raise ValueError("Цена должна быть больше 0")
            if data["discount"] < 0 or data["discount"] > 100:
                raise ValueError("Скидка должна быть от 0 до 100")
            if data["quantity"] < 0:
                raise ValueError("Количество не может быть отрицательным")

            current_id = self.product["id"] if self.product else 0
            if one("SELECT id FROM products WHERE LOWER(article)=LOWER(?) AND id<>?", (data["article"], current_id)):
                raise ValueError("Товар с таким артикулом уже существует")

            data["description"] = self.description.get("1.0", "end").strip()
            data["unit"] = data["unit"] or "шт."
            columns = ("article", "name", "description", "category", "price", "discount", "quantity", "supplier", "unit", "manufacturer", "image_url")
            with get_connection() as connection:
                if self.product:
                    values = [data[column] for column in columns] + [self.product["id"]]
                    connection.execute(f"UPDATE products SET {', '.join(column + '=?' for column in columns)} WHERE id=?", values)
                else:
                    values = [data[column] for column in columns]
                    marks = ", ".join("?" for _ in columns)
                    connection.execute(f"INSERT INTO products ({', '.join(columns)}) VALUES ({marks})", values)
            self.saved = True
            self.destroy()
        except (ValueError, sqlite3.IntegrityError) as error:
            self.error.configure(text=str(error))


class OrdersWindow(tk.Toplevel):
    def __init__(self, parent: ShoeShopApp) -> None:
        super().__init__(parent)
        self.title("Просмотр заказов")
        self.geometry("980x420")
        ttk.Label(self, text="Заказы", style="Title.TLabel").pack(anchor="w", padx=18, pady=(16, 10))

        columns = ("id", "user", "date", "delivery", "point", "code", "status", "total")
        titles = ("Номер", "Клиент", "Дата", "Доставка", "Пункт выдачи", "Код", "Статус", "Сумма")
        table = ttk.Treeview(self, columns=columns, show="headings")
        for column, title in zip(columns, titles):
            table.heading(column, text=title)
            table.column(column, width=120 if column != "point" else 260)
        table.pack(fill="both", expand=True, padx=18, pady=(0, 18))

        data = rows(
            """
            SELECT orders.*, users.full_name, pickup_points.address
            FROM orders
            JOIN users ON users.id = orders.user_id
            LEFT JOIN pickup_points ON pickup_points.id = orders.pickup_point_id
            ORDER BY orders.order_date DESC
            """
        )
        for order in data:
            table.insert("", "end", values=(
                order["id"], order["full_name"], order["order_date"][:10],
                (order["delivery_date"] or "")[:10], order["address"] or "",
                order["receive_code"], order["status"], f'{order["total_amount"]:.2f}',
            ))
